// CoCoTools_IO JavaScript Extensions Entry Point
import "./saver.js";
import "./load_exr.js";
import "./load_exr_layer_by_name.js";

console.log("CoCoTools_IO extensions loaded successfully");